"""Member 2 - Grid pressure section.     Run:  streamlit run grid_pressure.py

Question: where do data centres already take a large share of the electricity
grid, and how fast is that share rising?  (All data centres - the source cannot
isolate AI.)  Interactions: view, measure, year, locations, planner threshold.
"""
import io
import altair as alt
import pandas as pd
import streamlit as st

PROCESSED = "data/processed/grid_share.csv"
NAVY, ALERT, GREY = "#1F3A5F", "#E4572E", "#8A94A6"

# Entities overlap (US is inside North America, China inside Asia Pacific, World
# contains all), so the app only ever ranks NON-overlapping sets.
VIEWS = {
    "IEA world regions": ["Africa (IEA)", "Asia Pacific (IEA)", "Central and South America (IEA)",
                          "Europe (IEA)", "Middle East (IEA)", "North America (IEA)"],
    "US and China vs the rest": ["United States", "China", "World excl. United States and China"],
}
SHARE, CHANGE = "Share of electricity demand", "Change since 2020"
SOURCE = ("Source: Our World in Data, 'Share of total electricity demand coming from data centers' "
          "(IEA data-centre consumption divided by Ember total electricity demand), accessed 21 Oct 2026. "
          "Covers all data centres, not only AI.")

CSS = """
<style>
.hero{background:linear-gradient(120deg,#1F3A5F 0%,#2B5C8A 60%,#E4572E 130%);color:#fff;
      padding:22px 26px;border-radius:16px;margin-bottom:14px}
.hero h2{margin:0 0 4px 0;color:#fff;font-size:1.7rem}
.hero p{margin:0;opacity:.92;font-size:.98rem}
.kpis{display:flex;gap:12px;flex-wrap:wrap;margin:6px 0 10px}
.kpi{flex:1;min-width:170px;background:rgba(31,58,95,.07);border-left:5px solid #1F3A5F;
     padding:10px 14px;border-radius:10px}
.kpi.alert{border-left-color:#E4572E;background:rgba(228,87,46,.09)}
.kpi .lab{font-size:.78rem;text-transform:uppercase;letter-spacing:.04em;opacity:.75}
.kpi .val{font-size:1.65rem;font-weight:700;line-height:1.2}
.kpi .sub{font-size:.82rem;opacity:.8}
.note{background:rgba(228,87,46,.08);border:1px solid rgba(228,87,46,.35);padding:12px 16px;border-radius:12px}
</style>
"""


@st.cache_data
def load_processed():
    return pd.read_csv(PROCESSED)


def clean_upload(file):
    df = pd.read_csv(io.BytesIO(file.getvalue()))
    df = df.rename(columns={"Entity": "location", "Code": "code", "Year": "year", df.columns[-1]: "share_pct"})
    return df.dropna(subset=["share_pct"])[["location", "code", "year", "share_pct"]]


def get_data():
    try:
        return load_processed()
    except FileNotFoundError:
        st.info("Processed file missing. Run `python prepare_data.py` or upload the raw OWID CSV.")
        up = st.file_uploader("Raw OWID CSV", type="csv")
        return clean_upload(up) if up else None


def kpi(label, value, sub="", alert=False):
    return (f'<div class="kpi{" alert" if alert else ""}"><div class="lab">{label}</div>'
            f'<div class="val">{value}</div><div class="sub">{sub}</div></div>')


def render_global(df):
    years = sorted(df["year"].unique())
    c1, c2, c3 = st.columns(3)
    view = c1.radio("Compare", list(VIEWS), help="Both views are non-overlapping, so nothing is double counted.")
    metric = c2.radio("Measure", [SHARE, CHANGE])
    if metric == CHANGE:
        year = c3.select_slider("Compare 2020 with", options=[y for y in years if y > 2020], value=years[-1])
    else:
        year = c3.select_slider("Year", options=years, value=years[-1],
                                help="Only years in the source are offered; 2021-2022 are not estimated.")

    names = [n for n in VIEWS[view] if n in set(df["location"])]
    d1, d2 = st.columns([3, 2])
    chosen = d1.multiselect("Locations shown", names, default=names)
    threshold = d2.slider("Your attention threshold (% of demand)", 0.5, 6.0, 3.0, 0.5,
                          disabled=(metric == CHANGE),
                          help="Your own screening line, not an official limit. Places at or above it are flagged for closer review.")

    wide = df.pivot_table(index="location", columns="year", values="share_pct")

    def value(loc):
        if loc not in wide.index or pd.isna(wide.loc[loc].get(year)):
            return None
        if metric == CHANGE:
            base = wide.loc[loc].get(2020)
            return None if pd.isna(base) else float(wide.loc[loc, year] - base)
        return float(wide.loc[loc, year])

    data = pd.DataFrame([{"location": l, "value": value(l)} for l in chosen if value(l) is not None])
    if data.empty:
        st.warning("No data for this selection.")
        return
    data = data.sort_values("value", ascending=False)
    world = value("World")
    unit = "percentage points" if metric == CHANGE else "%"
    top, low = data.iloc[0], data.iloc[-1]

    cards = [kpi("Highest" if metric == SHARE else "Fastest rise", f"{top['value']:.2f}{'' if metric == CHANGE else '%'}",
                 f"{top['location']}, {year}"),
             kpi("World reference", f"{world:.2f}{'' if metric == CHANGE else '%'}" if world is not None else "n/a",
                 "all data centres, global")]
    if metric == SHARE:
        flagged = data[data["value"] >= threshold]
        cards.append(kpi("At or above threshold", f"{len(flagged)} of {len(data)}", f"threshold {threshold:.1f}%", alert=True))
    else:
        cards.append(kpi("Slowest rise", f"{low['value']:.2f}", low["location"]))
    st.markdown('<div class="kpis">' + "".join(cards) + "</div>", unsafe_allow_html=True)

    data["flag"] = ["At or above threshold" if (metric == SHARE and v >= threshold) else "Below threshold / n.a." for v in data["value"]]
    x_title = ("Data-centre share of electricity demand (%)" if metric == SHARE
               else f"Change in share, 2020 to {year} (percentage points)")
    bars = alt.Chart(data).mark_bar(cornerRadiusEnd=4).encode(
        x=alt.X("value:Q", title=x_title),
        y=alt.Y("location:N", sort="-x", title=None, axis=alt.Axis(labelLimit=260)),
        color=alt.Color("flag:N", scale=alt.Scale(domain=["At or above threshold", "Below threshold / n.a."],
                                                  range=[ALERT, NAVY]),
                        legend=alt.Legend(title=None, orient="bottom") if metric == SHARE else None),
        tooltip=["location", alt.Tooltip("value:Q", format=".2f", title=unit)])
    layers = bars + bars.mark_text(align="left", dx=5, color=GREY).encode(text=alt.Text("value:Q", format=".2f"), color=alt.value("#1B2A41"))
    if metric == SHARE:
        layers += alt.Chart(pd.DataFrame({"v": [threshold]})).mark_rule(color=ALERT, strokeDash=[5, 4]).encode(x="v:Q")
    if world is not None:
        layers += alt.Chart(pd.DataFrame({"v": [world]})).mark_rule(color=GREY, strokeDash=[2, 3], size=2).encode(x="v:Q")
    st.altair_chart(layers.properties(height=max(200, 46 * len(data))), width="stretch")
    st.caption("Grey dotted line = world; orange dashed line = your threshold." if metric == SHARE else "Grey dotted line = world.")

    if metric == SHARE:
        if len(flagged):
            names_txt = ", ".join(f"<b>{r.location}</b> ({r.value:.1f}%)" for r in flagged.itertuples())
            if len(flagged) == 1:
                msg = (f"In {year}, {names_txt} is the only region at or above the {threshold:.1f}% threshold. "
                       f"This is a candidate for closer assessment. A regional or national share cannot show strain on a single local grid.")
            else:
                msg = (f"In {year}, {names_txt} are at or above the {threshold:.1f}% threshold. These are candidates for closer "
                       f"assessment. A regional or national share cannot show strain on a single local grid.")
        else:
            msg = (f"No selected place reaches {threshold:.1f}% in {year}. That does not clear any local grid: "
                   f"averages can hide hotspots.")
        st.markdown(f'<div class="note"><b>What this means for the planner.</b> {msg}</div>', unsafe_allow_html=True)

    with st.expander("Trace the numbers (raw source rows)"):
        st.dataframe(df[df["location"].isin(chosen + ["World"]) & df["year"].isin([2020, year])]
                     .sort_values(["location", "year"]), hide_index=True, width="stretch")
        st.caption("Share = IEA data-centre electricity / Ember total demand x 100. Change = share(year) - share(2020).")
    with st.expander("Sources, assumptions and limits"):
        st.markdown(f"{SOURCE}\n\n- Overlapping entities are never ranked together.\n"
                    "- Only 2020 and 2023-2025 exist; gaps are not filled.\n- IEA regions exclude Eurasia.\n"
                    "- Shares describe whole regions, not individual grids or sites.\n"
                    "- Underlying IEA terms apply; see OWID for reuse conditions.")


AUS = "data/processed/australia_aemo.csv"


def render_australia():
    a = pd.read_csv(AUS)
    st.markdown("### Australia spotlight")
    st.markdown("Australia is **not a separate row in the global OWID file**, so this tab uses AEMO, Australia's energy market operator. "
                "AEMO figures cover the grid (mostly the National Electricity Market, NEM) over financial years, so they are "
                "**not like-for-like** with the OWID bars. Treat comparisons as indicative only.")
    only_primary = st.checkbox("Only values read directly from AEMO's own page", value=False,
                               help="Other values come from news or NGO reports of AEMO figures and should be confirmed in AEMO's documents.")
    d = a[a["in_chart"] == "yes"].copy()
    if only_primary:
        d = d[d["evidence"] == "primary"]
    d = d.dropna(subset=["share_pct"]).sort_values("sort_key")

    now = a[a["label"].str.startswith("Mid-2026")].iloc[0]
    esoo26 = a[a["label"] == "2025-26"].iloc[0]
    esoo36 = a[a["label"] == "2035-36"].iloc[0]
    st.markdown('<div class="kpis">' + kpi("AEMO, June 2026", f"~{now['share_pct']:.0f}%", "of grid-supplied electricity today")
                + kpi("AEMO ESOO, Aug 2026", f"~{esoo26['share_pct']:.0f}% to ~{esoo36['share_pct']:.0f}%", "2025-26 to 2035-36 (Step Change)", alert=True)
                + kpi("Operational data centres", "162", "Australia, per AEMO (Jun 2026)") + "</div>", unsafe_allow_html=True)

    if d.empty:
        st.warning("No values match this filter.")
    else:
        order = d["label"].tolist()
        base = alt.Chart(d).encode(
            x=alt.X("label:N", sort=order, title="Period (financial year or calendar year as reported)"),
            y=alt.Y("share_pct:Q", title="Data-centre share of grid electricity (%)"),
            color=alt.Color("publication:N", legend=alt.Legend(title=None, orient="bottom", labelLimit=420)),
            tooltip=["label", "share_pct", "consumption_twh", "status", "scenario", "evidence", "denominator"])
        chart = base.mark_line(strokeDash=[4, 3], opacity=.6) + base.mark_point(size=140, filled=True) + \
            base.mark_text(dy=-14, fontWeight="bold").encode(text=alt.Text("share_pct:Q", format=".0f"))
        st.altair_chart(chart.properties(height=340), width="stretch")
        st.caption("Dashed lines join values from the same publication. Points before 'Now' are estimates; later points are forecasts.")

    st.markdown('<div class="note"><b>Why the two publications differ.</b> AEMO\'s 2025 IASR and 2026 ESOO use different bases '
                '(grid-supplied vs operational demand) and report different dates for about 34 TWh (2050 vs 2035-36). '
                'Reports of the 2026 ISP also give almost 10% by 2050. Quote the report and year with every figure.</div>', unsafe_allow_html=True)

    with st.expander("Check it yourself: a simple consistency test"):
        base_twh, nem_twh = 3.9, 205
        st.markdown(f"{base_twh} TWh / about {nem_twh} TWh NEM consumption = **{base_twh / nem_twh * 100:.1f}%**, "
                    "consistent with AEMO's 'about 2%'. The 205 TWh denominator comes from a news report of the 2026 ISP "
                    "(secondary): confirm it in AEMO's ISP before using it on camera.")
    with st.expander("Australia data table and sources"):
        st.dataframe(a.drop(columns=["in_chart"]), hide_index=True, width="stretch")
        st.caption("Evidence 'primary' = read on AEMO's own page; 'secondary' = reported by others. See data/raw/australia_sources.md.")


def render():
    st.markdown(CSS, unsafe_allow_html=True)
    st.markdown('<div class="hero"><h2>Grid pressure</h2>'
                '<p>How much of each electricity system do data centres already use, and how fast is that rising? '
                'Built for a regional infrastructure planner deciding where a new data centre needs closer assessment.</p></div>',
                unsafe_allow_html=True)
    df = get_data()
    if df is None:
        return
    t1, t2 = st.tabs(["Global comparison (OWID/IEA)", "Australia spotlight (AEMO)"])
    with t1:
        render_global(df)
        st.caption("Dataset last updated by OWID on 30 Jun 2026; series ends 2025; next update expected 30 Jun 2027. Checked 21 Oct 2026.")
    with t2:
        render_australia()



if __name__ == "__main__":
    st.set_page_config(page_title="Grid pressure", page_icon="⚡", layout="wide")
    render()
